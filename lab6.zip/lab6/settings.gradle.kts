
rootProject.name = "lab6"

